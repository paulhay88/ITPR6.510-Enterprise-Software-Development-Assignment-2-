# ITPR6.510-Enterprise-Software-Development-Assignment-2-
You will build an application in the language Go in a team of 2 people. It is important you will clearly identify your contribution to the project. You will get an individual mark based on your contribution and your role in the team
